﻿using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("com.unity.cinemachine.editor")]
[assembly: InternalsVisibleTo("Cinemachine.Runtime.Tests")]
