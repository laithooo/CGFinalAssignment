using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Toggle : MonoBehaviour
{
    public Material defaultMaterial;  
    public Material alternateMaterial;  
    private Renderer objRenderer;  
    private bool isAlternateMaterial = false;  

    void Start()
    {
     
        objRenderer = GetComponent<Renderer>();

    
        if (defaultMaterial != null)
        {
            objRenderer.material = defaultMaterial;
        }
    }

    void Update()
    {
        
        if (Input.GetKeyDown(KeyCode.F1))
        {
            ToggleMaterial();
        }
    }

    void ToggleMaterial()
    {
        if (defaultMaterial != null && alternateMaterial != null)
        {
       
            if (isAlternateMaterial)
            {
                objRenderer.material = alternateMaterial;
            }
            else
            {
                objRenderer.material = defaultMaterial;
            }

            isAlternateMaterial = !isAlternateMaterial;

        }
    }

}

