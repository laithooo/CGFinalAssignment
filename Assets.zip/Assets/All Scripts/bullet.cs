using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class bullet : MonoBehaviour
{

    private Rigidbody _rb;

    private void Awake()
    {
        _rb = GetComponent<Rigidbody>();
    }


    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }


    public void Fire(float speed, Vector3 direction)
    {
        _rb.velocity = direction * speed;
    }

    void OnCollisionEnter(Collision collider)
    {
        if (collider.gameObject.tag == "RadioTower")
        {
            SceneManager.LoadScene(1);

        }
    }
}
