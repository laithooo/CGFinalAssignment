using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Health : MonoBehaviour
{

    public int health;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (health < 0)
        {
            gameObject.SetActive(false);
            SceneManager.LoadScene(2);
        }
    }
    public void takeDamage()
    {
        health--;
    }
}
