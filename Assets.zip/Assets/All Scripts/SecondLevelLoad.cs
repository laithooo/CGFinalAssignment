using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SecondLevelLoad : MonoBehaviour
{
    private bool isNearObject = false; 

    private void Update()
    {
        
        if (isNearObject && Input.GetKeyDown(KeyCode.E)) 
        {
            LoadTargetScene();
        }
    }

    private void LoadTargetScene()
    {
        SceneManager.LoadScene(3);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            isNearObject = true;
            Debug.Log("Press 'E' to interact.");
        }
    }
}

