using System.Collections;
using System.Collections.Generic;
using UnityEngine.AI;
using UnityEngine;

public class Enemy : MonoBehaviour
{


    [SerializeField] private bullet bulletPrefab;

    public NavMeshAgent agent;

    public Transform Player;

    public LayerMask whatIsGround, whatIsPlayer;

    //to try to make enemy patrol
    public Vector3 walkPoint;
    bool walkPointSet;
    public float walkPointRange;


    //enemy attacks
    public float timeBetweenAttacks;




    public float sightRange, attackRange;
    public bool playerInSightRange, playerInAttackRange;


    private void Awake()
    {
        Player = GameObject.Find("Player").transform;
        agent = GetComponent<NavMeshAgent>();

    }




    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

        // do some more research about physics checksphere since it doesnt always work, regardless make 3 stages to make enemy either move around or chase or attack


        playerInSightRange = Physics.CheckSphere(transform.position, sightRange, whatIsPlayer);
        playerInAttackRange = Physics.CheckSphere(transform.position, attackRange, whatIsPlayer);


        if (!playerInAttackRange && !playerInSightRange)
        {
            Patrol();
        }

        if (playerInSightRange && playerInAttackRange)
        {
            ChasePlayer();
        }
        if (playerInAttackRange && playerInSightRange)
        {
            AttackPlayer();
        }
    }


    // now i put these after update because i have to see if player gameobject is detected first then the enemy will attack
    private void Patrol()
    {
        if (!walkPointSet)
        {
            SearchWalkPoint();
        }

        if (walkPointSet)
        {
            agent.SetDestination(walkPoint);

            Vector3 distanceToWalkPoint = transform.position - walkPoint;

            if (distanceToWalkPoint.magnitude < 1f)
                walkPointSet = false;
        }
    }



    private void SearchWalkPoint()
    {
        float randomZ = Random.Range(-walkPointRange, walkPointRange);
        float randomX = Random.Range(-walkPointRange, walkPointRange);

        walkPoint = new Vector3(transform.position.x + randomX, transform.position.y, transform.position.z + randomZ);

        if (Physics.Raycast(walkPoint, -transform.up, 2f, whatIsGround))
        {
            walkPointSet = true;
        }


    }
    private void ChasePlayer()
    {

        agent.SetDestination(Player.position);
    }

    private void AttackPlayer()
    {
        agent.SetDestination(Player.position);
        transform.Rotate(0, 90, 0);
        transform.LookAt(Player);
        RaycastHit hit;
        Health playerHealth;

        if (Physics.Raycast(transform.position, transform.forward, out hit))
        {
            if (hit.transform.tag == "Player")
            {
                playerHealth = hit.transform.GetComponent<Health>();
                playerHealth.takeDamage();

            }
        }

    }

    void OnCollisionEnter (Collision collider)
    {
        if (collider.gameObject.tag == "bullet")
        {
            Destroy(this.gameObject);

        }
    }
}
