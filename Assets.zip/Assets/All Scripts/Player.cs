using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    CharacterController characterController;
    public Camera playerCamera;
    
    [SerializeField]
    float speed = 4f;

    float cameraSpeed = 2f;
    float rotationX = 0;
    float lookXLimit = 45f;

    // Start is called before the first frame update
    void Start()
    {
        characterController = GetComponent<CharacterController>();
        Cursor.lockState = CursorLockMode.Locked;
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(speed * Vector3.forward * Time.deltaTime * Input.GetAxis("Vertical"));
        transform.Translate(speed * Vector3.right * Time.deltaTime * Input.GetAxis("Horizontal"));


        rotationX += -Input.GetAxis("Mouse Y") * cameraSpeed;
        rotationX = Mathf.Clamp(rotationX, -lookXLimit, lookXLimit);
        playerCamera.transform.localRotation = Quaternion.Euler(rotationX, 0, 0);
        transform.rotation *= Quaternion.Euler(0, Input.GetAxis("Mouse X") * cameraSpeed, 0);
    }       
    
}
