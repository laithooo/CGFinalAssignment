using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class Shoot : MonoBehaviour
{
    [SerializeField] private float bulletSpeed;
    [SerializeField] private bullet bulletPrefab;

    private void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            var position = transform.position + transform.forward;
            var rotation = transform.rotation;
            var bullet = Instantiate(bulletPrefab, position, rotation);
            bullet.Fire(bulletSpeed, transform.forward);
        }
    }
}
